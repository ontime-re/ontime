from ..utils import DynamicClass


class Detectors(DynamicClass):
    def __init__(self):
        super().__init__()
