onTime
======

A library to work with time series

## Getting Started

TODO

## Documentation

TODO

## Authors

TODO

## License

TODO
