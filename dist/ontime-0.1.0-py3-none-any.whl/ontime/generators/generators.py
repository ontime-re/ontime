from ..utils import DynamicClass


class Generators(DynamicClass):
    def __init__(self):
        super().__init__()
