from ..utils import DynamicClass


class Models(DynamicClass):
    def __init__(self):
        super().__init__()
