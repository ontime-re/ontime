from ..utils import DynamicClass


class Processors(DynamicClass):
    def __init__(self):
        super().__init__()
